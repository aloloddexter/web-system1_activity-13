<!DOCTYPE html>

<html>

<title>LOG-IN</title>


                        <div class="log-in">
                            
                            <center>
                           <form action="login.php" method="post">
                                <fieldset>
                                    <legend>LOG-IN</legend>
                                        <label for="username">Username: </label>
                                        <input type="text" name="username" required><br><br>
                                        <label for="password">Password:</label>
                                        <input type="password" name="password" required> <br> <br>
                                        <label">Dont have a account?:</label>
                                    
                                        <input type="submit" name="login" value="LOG-IN">

                                        <p><a href="register.php">Register</a></p>
                                        
                                </fieldset>
                            </form>
                            </center>
                        </div>

              
</body>
</html>