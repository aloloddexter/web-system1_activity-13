<?php
require_once("connect.php");

if(isset($_GET['search'])) {
    $search = $_GET['search'];
   
    $query = "SELECT * FROM register WHERE status='Active' AND (lastname LIKE '%$search%' OR firstname LIKE '%$search%');";
    $result = mysqli_query($packer, $query);
    $num_rows = mysqli_num_rows($result);

    if ($num_rows > 0) {
        while($row = mysqli_fetch_array($result)) {
            echo "<div>".$row['firstname']." ".$row['lastname']."</div>";
        }
    } else {
        echo "No results found.";
    }
}
?>
