<!DOCTYPE html>
<html>
    <head>
        <title>helloo!</title>
    </head>
    <body>
    <a href="display.php">Account</a><br><br>
    <?php
    require_once("connect.php");
    if(isset($_POST['submit'])){
        $lname = $_POST['lname'];
        $fname = $_POST['fname'];
        $uname = $_POST['uname'];
        $pword = $_POST['pword'];
        mysqli_query($packer, "INSERT INTO register (id, lastname, firstname, username, password, status) VALUES (NULL,'$lname', '$fname', '$uname', '$pword', 'Active');");
        header("Location: main.php"); 
        exit(); 
    }
    ?>
    <form action="" method="post">
        <input type="text" name="lname" placeholder="Last Name" required/>&nbsp;
        <input type="text" name="fname" placeholder="First Name" required/><br><br>
        <input type="text" name="uname" placeholder="Username" required/><br><br>
        <input type="password" name="pword" placeholder="Password" required/><br><br>
        <input type="submit" name="submit" value="Submit"/>
    </form>
    </body>
</html>
