<?php
session_start(); // Start the session

// Check if the user is logged in
if (isset($_SESSION['username'])) {
    $loggedInUsername = $_SESSION['username'];
    
    // Retrieve the first name of the logged-in user
    require_once("connect.php"); // Include the database connection file

    // Prepare and execute the query
    $query = "SELECT firstname FROM register WHERE username = '$loggedInUsername'";
    $result = mysqli_query($packer, $query);

    if ($result && mysqli_num_rows($result) > 0) {
        $row = mysqli_fetch_assoc($result);
        $loggedInFirstName = $row['firstname'];
    } else {
        // Handle the case where the user's first name is not found
        $loggedInFirstName = "Unknown";
    }

    // Free the result set
    mysqli_free_result($result);

    // Close the database connection
    mysqli_close($packer);
} else {
    // Redirect the user to the login page if not logged in
    header("Location: login.php");
    exit();
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Hello!</title>
</head>

<body>
    <h1>Welcome, <?php echo $loggedInFirstName; ?>!</h1>
    <!-- Rest of your HTML code -->
</body>
</html>
