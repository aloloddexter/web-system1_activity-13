<?php
session_start();

// Check if the user is logged in
if (isset($_SESSION['username'])) {
    $loggedInFirstName = $_SESSION['firstname'];
} else {
    // Redirect the user to the login page if not logged in
    header("Location: login.php");
    exit();
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Welcome</title>
</head>

<body>
    <h1>Welcome, <?php echo $loggedInFirstName; ?>!</h1>

    <!-- Rest of your HTML code -->
    
    <form method="GET" action="">
        <input type="text" name="search" placeholder="Search">
        <input type="submit" value="Submit">
    </form>
    <br>
    
    <table border="1" cellspacing="0">
        <tr>
            <td>ID Number</td>
            <td>Last Name</td>
            <td>First Name</td>
            <td>Username</td>
            <td>Password</td>
            <td>Status</td>
            <td>Action</td>
        </tr>
        <?php
        require_once("connect.php");
        
        // Check if a search query is submitted
        if (isset($_GET['search'])) {
            $search = $_GET['search'];
            // Prepare the query with LIKE syntax
            $query = "SELECT * FROM register WHERE status='Active' AND (lastname LIKE '%$search%' OR firstname LIKE '%$search%' OR username LIKE '%$search%');";
        } else {
            // Default query without search
            $query = "SELECT * FROM register WHERE status='Active';";
        }

        $result = mysqli_query($packer, $query);
        if ($result) {
            while ($row = mysqli_fetch_array($result)) {
                ?>
                <tr>
                    <td><?php echo $row['id']; ?></td>
                    <td><?php echo $row['lastname']; ?></td>
                    <td><?php echo $row['firstname']; ?></td>
                    <td><?php echo $row['username']; ?></td>
                    <td><?php echo $row['password']; ?></td>
                    <td><?php echo $row['status']; ?></td>
                    <td>
                        <a href="update.php?id_num=<?php echo $row['id']; ?>">Edit</a> |
                        <a href="delete.php?id_num=<?php echo $row['id']; ?>">Delete</a>
                    </td>
                </tr>
                <?php
            }
        } else {
            echo "Error executing the query: " . mysqli_error($packer);
        }
        ?>
    </table>
</body>
</html>
