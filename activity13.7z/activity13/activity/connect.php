<?php

$packer = mysqli_connect("localhost", "root", "", "activty13")
or die ("Cannot connect to the database");
?>