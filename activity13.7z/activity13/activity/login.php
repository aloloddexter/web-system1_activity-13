<?php
session_start();
require_once("connect.php");

if (isset($_POST['login'])) {
    $username = $_POST['username'];
    $password = $_POST['password'];

    $query = "SELECT * FROM register WHERE username='$username' AND password='$password';";
    $result = mysqli_query($packer, $query);

    if ($result && mysqli_num_rows($result) > 0) {
        $row = mysqli_fetch_assoc($result);
        $_SESSION['username'] = $row['username']; // Store the username in the session
        $_SESSION['firstname'] = $row['firstname']; // Store the first name in the session
        header("location: display.php");
        exit();
    } else {
        ?>
        <script>
            alert("Invalid username or password");
        </script>
        <?php
    }
}
?>
