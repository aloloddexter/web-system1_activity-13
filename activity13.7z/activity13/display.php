<!DOCTYPE html>
<html>
<head>
    <title>helloo!</title>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
    <script>
        $(document).ready(function() {
            $("#search").keyup(function() {
                var inputVal = $(this).val();
                $.ajax({
                    type: "GET",
                    url: "search.php",
                    data: { search: inputVal },
                    success: function(data) {
                        $("#search-suggestions").html(data);
                    }
                });
            });
        });
    </script>
</head>
<body>
    <form method="GET" action="">
        <input type="text" name="search" id="search" placeholder="Search">
        <input type="submit" value="Submit">
    </form>
    <br>
    <div id="search-suggestions"></div>

    <?php
    require_once("connect.php");

    // Check if a search query is submitted
    if(isset($_GET['search'])) {
        $search = $_GET['search'];
        // Prepare the query with LIKE syntax
        $query = "SELECT * FROM cruds WHERE status='Active' AND (lastname LIKE '%$search%' OR firstname LIKE '%$search%' OR email LIKE '%$search%');";
        $result = mysqli_query($packer, $query);
        $num_rows = mysqli_num_rows($result);

        if ($num_rows > 0) {
            ?>
            <table border="1" cellspacing="0">
                <tr>
                    <td>ID Number</td>
                    <td>Last Name</td>
                    <td>First Name</td>
                    <td>Age</td>
                    <td>Email Address</td>
                    <td>Status</td>
                    <td>Action</td>
                </tr>
                <?php
                while($row = mysqli_fetch_array($result)) {
                    ?>
                    <tr>
                        <td><?php echo $row['id']; ?></td>
                        <td><?php echo $row['lastname']; ?></td>
                        <td><?php echo $row['firstname']; ?></td>
                        <td><?php echo $row['age']; ?></td>
                        <td><?php echo $row['email']; ?></td>
                        <td><?php echo $row['status']; ?></td>
                        <td>
                            <a href="update.php?id_num=<?php echo $row['id']; ?>">Edit</a> |
                            <a href="delete.php?id_num=<?php echo $row['id']; ?>">Delete</a>
                        </td>
                    </tr>
                    <?php
                }
                ?>
            </table>
            <?php
        } else {
            echo "No results found.";
        }
    }
    ?>
</body>
</html>
