<?php

$packer = mysqli_connect("localhost", "root", "", "summer")
or die ("Cannot connect to the database");
?>