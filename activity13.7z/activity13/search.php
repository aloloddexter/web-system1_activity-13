<?php
require_once("connect.php");

if(isset($_GET['search'])) {
    $search = $_GET['search'];
    // Prepare the query with LIKE syntax
    $query = "SELECT * FROM cruds WHERE status='Active' AND (lastname LIKE '%$search%' OR firstname LIKE '%$search%' OR email LIKE '%$search%');";
    $result = mysqli_query($packer, $query);
    $num_rows = mysqli_num_rows($result);

    if ($num_rows > 0) {
        while($row = mysqli_fetch_array($result)) {
            echo "<div>".$row['firstname']." ".$row['lastname']."</div>";
        }
    } else {
        echo "No results found.";
    }
}
?>
